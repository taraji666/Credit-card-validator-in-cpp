#include <iostream>
#include <list>

//  Start validation
bool validation(const std::string &cardNumber)
{
    std::list<int> evenNumbers;
    std::list<int> oddNumbers;
    bool isOdd;

    //  Separate EVEN and ODD places from the number
    for(auto digit : cardNumber)
    {
        if (!isOdd)
            evenNumbers.push_back(std::stoi(&digit));
        else
            oddNumbers.push_back(std::stoi(&digit));

        isOdd = !isOdd;
    }

    //  Multiply every even digit by 2. if the result is made of two digits, add it.
    for (auto &digit : evenNumbers)
    {
        digit *= 2;

        //  Check if it's two digits and add it
        std::string n = std::to_string(digit);

        if (n.size() == 2)
            digit = (n[0] - '0') + (n[1] - '0');
    }

    //  Add all elements of Even
    int evenSum(0);

    for (auto digit : evenNumbers)
        evenSum += digit;

    //  Add all elements of Odd
    int oddSum(0);

    for (auto digit : oddNumbers)
        oddSum += digit;

    //  Add the total of even and odd.
    //  check if the sum is divisible by 10,
    //      then the bank card is valid.
    if ((evenSum + oddSum) % 10 == 0)
        return true;
    else
        return false;

}

int main()
{
    std::string cardNumber("4847451989263094");

    std::cout<< "Enter your credit card: ";
    std::cin>>cardNumber;

    //  Check if the card number has at least 2 digits
    if (cardNumber.length() >= 2)
    {
        if (validation(cardNumber))
            std::cout<< "Your credit card is valid" <<std::endl;
        else
            std::cout<< "Invalid credit card" <<std::endl;
    }

    return 0;
}


//"4847352989263094"
